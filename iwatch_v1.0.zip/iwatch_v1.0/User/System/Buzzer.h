#ifndef  _BUZZER_H
#define  _BUZZER_H


void BuzzerInit(void);
void BuzzerOnOff(unsigned char b);
void Bee(void);
void Beebeebee(void);
void EnableBuzzer(unsigned char k);


#endif





