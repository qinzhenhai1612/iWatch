#ifndef  _DELAY_H
#define  _DELAY_H


void Delay1ms(unsigned int t);

#endif















